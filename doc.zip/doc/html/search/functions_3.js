var searchData=
[
  ['getrh_11',['getRH',['../class_d_h_t.html#aed9877eb32bda896cb59f1675b072d1a',1,'DHT']]],
  ['gett_12',['getT',['../class_d_h_t.html#a27ba8899a9551fc692a1d72923b972ec',1,'DHT']]]
];
